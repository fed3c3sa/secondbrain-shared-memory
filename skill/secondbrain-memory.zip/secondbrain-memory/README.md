# SecondBrain Memory skill

Gives your assistant a persistent, personal memory backed by your [SecondBrain](https://secondbrain.icu) notes. It recalls what you told it in past sessions, saves durable facts and decisions into your own SecondBrain folders, links related notes, and can set calendar events and reminders. The same memory is shared across every assistant you connect (Claude, ChatGPT, Cursor, Gemini), because it all lives in your SecondBrain account.

`SKILL.md` is the actual skill definition (Claude reads it). This README is just for you.

## Requirements

- A SecondBrain account with an active **Pro** subscription (upgrade in the SecondBrain app).
- The **SecondBrain MCP server** connected in your assistant. The fastest way to set everything up is one command in a terminal:

  ```bash
  npx secondbrain-connect
  ```

  It signs you in with Apple or Google and auto-configures the MCP server (and installs this skill on Claude Code automatically). For Claude Desktop, also upload this skill as described below.

## Install in Claude Desktop

1. Make sure the SecondBrain MCP server is connected. Running `npx secondbrain-connect` configures Claude Desktop for you (or add the MCP server manually in Settings).
2. Open Claude Desktop, go to **Settings -> Capabilities -> Skills**.
3. Choose **Upload skill** and select the `secondbrain-memory.zip` file.
4. Enable the skill, then fully quit and reopen Claude Desktop so both the MCP server and the skill load.

## What it does

- **Recall:** searches your memory at the start of a task and whenever you refer to something from earlier ("the project", "that bug", "like last time").
- **Remember:** saves solved problems and their fix, decisions and the why, project and stack facts, commands, and gotchas, into your existing folders.
- **Connect:** links related notes across folders automatically.
- **Schedule:** adds calendar events and reminders for time-bound items.

## Privacy

Memories are ordinary notes in your own SecondBrain folder tree, visible and editable in the app. The skill never stores secrets, API keys, or passwords. Learn more at [secondbrain.icu](https://secondbrain.icu).
